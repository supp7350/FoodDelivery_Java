import java.awt.Color;

public class OptionPane {

    public static void showMessageDialog(Color color) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'showMessageDialog'");
    }

}
