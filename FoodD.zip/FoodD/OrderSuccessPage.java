import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.Timer;

public class OrderSuccessPage extends JFrame {
    private JLabel messageLabel;
    private JLabel emojiLabel;
    private Timer animationTimer;
    private int alpha = 0; // For fade-in effect

    public OrderSuccessPage() {
        setTitle("Order Success");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        messageLabel = new JLabel("Order Placed Successfully", SwingConstants.CENTER);
        messageLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        messageLabel.setForeground(new Color(0, 128, 0, alpha));
        add(messageLabel, BorderLayout.CENTER);

        emojiLabel = new JLabel();
        emojiLabel.setHorizontalAlignment(SwingConstants.CENTER);
        emojiLabel.setVisible(false);
        add(emojiLabel, BorderLayout.SOUTH);

        // Timer for fade-in animation of message
        animationTimer = new Timer(50, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                alpha += 15;
                if (alpha > 255) {
                    alpha = 255;
                    animationTimer.stop();
                    showEmoji();
                }
                messageLabel.setForeground(new Color(0, 128, 0, alpha));
                repaint();
            }
        });
        animationTimer.start();
    }

    private void showEmoji() {
        // Show animated smiley emoji (using a GIF)
        ImageIcon emojiIcon = new ImageIcon(getClass().getResource("/assets/smiley.gif"));
        emojiLabel.setIcon(emojiIcon);
        emojiLabel.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            OrderSuccessPage successPage = new OrderSuccessPage();
            successPage.setVisible(true);
        });
    }
}
