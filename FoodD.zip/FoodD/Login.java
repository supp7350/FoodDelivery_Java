import javax.swing.*;  
import java.awt.*;  
import java.awt.event.ActionEvent;  
import java.awt.event.ActionListener;  
import java.io.File;  
import java.io.IOException;  
import javax.imageio.ImageIO;  

public class Login extends JFrame {  
    private JTextField usernameField;  
    private JPasswordField passwordField;  
    private JButton loginButton;  
    private JButton signupButton;  
    private JLabel messageLabel;  
    private Image backgroundImage;  

    public Login() {  
        setTitle("Food Delivery App - Login");  
        setSize(500, 500);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        setLocationRelativeTo(null);  

        try {  
            backgroundImage = ImageIO.read(new File("C:\\Users\\INDIA\\Desktop\\FoodD\\assets\\BG1.jpg"));  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  

        BackgroundPanel backgroundPanel = new BackgroundPanel();  
        backgroundPanel.setLayout(new GridBagLayout());  
        setContentPane(backgroundPanel);  

        GridBagConstraints gbc = new GridBagConstraints();  
        gbc.insets = new Insets(10, 10, 10, 10);  
        gbc.fill = GridBagConstraints.HORIZONTAL;  

        // Username Label and Field  
        gbc.gridx = 0;  
        gbc.gridy = 0;  
        JLabel usernameLabel = new JLabel("Username:");  
        usernameLabel.setForeground(Color.BLACK);  
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 18));  
        backgroundPanel.add(usernameLabel, gbc);  

        gbc.gridx = 1;  
        usernameField = new JTextField(30);  
        usernameField.setFont(new Font("Arial", Font.PLAIN, 18));  
        backgroundPanel.add(usernameField, gbc);  

        // Password Label and Field  
        gbc.gridx = 0;  
        gbc.gridy = 1;  
        JLabel passwordLabel = new JLabel("Password:");  
        passwordLabel.setForeground(Color.BLACK);  
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 18));  
        backgroundPanel.add(passwordLabel, gbc);  

        gbc.gridx = 1;  
        passwordField = new JPasswordField(30);  
        passwordField.setFont(new Font("Arial", Font.PLAIN, 18));  
        backgroundPanel.add(passwordField, gbc);  

        // Login Button  
        gbc.gridx = 0;  
        gbc.gridy = 2;  
        gbc.gridwidth = 2;  
        gbc.anchor = GridBagConstraints.CENTER;  
        loginButton = new JButton("Login");  
        loginButton.setPreferredSize(new Dimension(40, 40));  
        loginButton.setBackground(new Color(70, 130, 180)); // Steel Blue  
        loginButton.setForeground(Color.WHITE);  
        loginButton.setFont(new Font("Arial", Font.BOLD, 18));  
        backgroundPanel.add(loginButton, gbc);  

        // Message Label  
        gbc.gridx = 0;  
        gbc.gridy = 3;  
        gbc.gridwidth = 2;  
        gbc.anchor = GridBagConstraints.CENTER;  
        messageLabel = new JLabel("If not registered, please sign up.");  
        messageLabel.setForeground(Color.BLACK);  
        messageLabel.setFont(new Font("Arial", Font.ITALIC, 16));  
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);  
        backgroundPanel.add(messageLabel, gbc);  

        // Signup Button  
        gbc.gridx = 0;  
        gbc.gridy = 4;  
        gbc.gridwidth = 2;  
        gbc.anchor = GridBagConstraints.CENTER;  
        signupButton = new JButton("Sign Up");  
        signupButton.setPreferredSize(new Dimension(40, 40));  
        signupButton.setBackground(new Color(34, 139, 34)); // Forest Green  
        signupButton.setForeground(Color.WHITE);  
        signupButton.setFont(new Font("Arial", Font.BOLD, 18));  
        backgroundPanel.add(signupButton, gbc);  

        // Add action listeners  
        loginButton.addActionListener(new ActionListener() {  
            @Override  
            public void actionPerformed(ActionEvent e) {  
                String username = usernameField.getText();  
                String password = new String(passwordField.getPassword());  

                // For demonstration, just print the input values  
                JOptionPane.showMessageDialog(Login.this,  
                        "Login clicked\nUsername: " + username);  
            }  
        });  

        signupButton.addActionListener(new ActionListener() {  
            @Override  
            public void actionPerformed(ActionEvent e) {  
                JOptionPane.showMessageDialog(Login.this, "Redirecting to Sign Up page...");  
            }  
        });  
    }  

    private class BackgroundPanel extends JPanel {  
        @Override  
        protected void paintComponent(Graphics g) {  
            super.paintComponent(g);  
            if (backgroundImage != null) {  
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);  
            }  
        }  
    }  

    public static void main(String[] args) {  
        SwingUtilities.invokeLater(new Runnable() {  
            @Override  
            public void run() {  
                new Login().setVisible(true);  
            }  
        });  
    }  
}
