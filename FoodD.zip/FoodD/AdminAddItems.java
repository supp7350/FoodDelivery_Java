import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class AdminAddItems extends JFrame {
    // Food item data class (same as in List.java)
    public static class FoodItem {
        String name;
        String type;
        String description;
        double cost;

        public FoodItem(String name, String type, String description, double cost) {
            this.name = name;
            this.type = type;
            this.description = description;
            this.cost = cost;
        }
    }

    private java.util.List<FoodItem> foodItems;
    private JTextField nameField;
    private JTextArea descriptionArea;
    private JComboBox<String> typeComboBox;
    private JTextField priceField;
    private JLabel statusLabel;

    public AdminAddItems(java.util.List<FoodItem> foodItems) {
        this.foodItems = (foodItems != null) ? foodItems : new ArrayList<>();

        setTitle("Admin - Add Food Item");
        setSize(400, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Product Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Product Name:"), gbc);

        nameField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(nameField, gbc);

        // Product Description
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Product Description:"), gbc);

        descriptionArea = new JTextArea(5, 20);
        JScrollPane descScrollPane = new JScrollPane(descriptionArea);
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(descScrollPane, gbc);

        // Product Category
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Product Category:"), gbc);

        String[] categories = {"Pizza", "Burger", "Rolls", "Sabji", "Street Food", "Desert", "Other"};
        typeComboBox = new JComboBox<>(categories);
        gbc.gridx = 1;
        gbc.gridy = 2;
        formPanel.add(typeComboBox, gbc);

        // Product Price
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Product Price (₹):"), gbc);

        priceField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 3;
        formPanel.add(priceField, gbc);

        // Add Button
        JButton addButton = new JButton("Add Item");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(addButton, gbc);

        // Status Label
        statusLabel = new JLabel(" ");
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        formPanel.add(statusLabel, gbc);

        add(formPanel, BorderLayout.CENTER);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addItem();
            }
        });
    }

    private void addItem() {
        String name = nameField.getText().trim();
        String description = descriptionArea.getText().trim();
        String type = (String) typeComboBox.getSelectedItem();
        String priceText = priceField.getText().trim();

        if (name.isEmpty() || description.isEmpty() || priceText.isEmpty()) {
            statusLabel.setText("Please fill all fields.");
            statusLabel.setForeground(Color.RED);
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
            if (price < 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            statusLabel.setText("Invalid price value.");
            statusLabel.setForeground(Color.RED);
            return;
        }

        FoodItem newItem = new FoodItem(name, type, description, price);
        foodItems.add(newItem);

        statusLabel.setText("Item added successfully!");
        statusLabel.setForeground(new Color(0, 128, 0));

        // Clear fields
        nameField.setText("");
        descriptionArea.setText("");
        priceField.setText("");
        typeComboBox.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AdminAddItems adminAddItems = new AdminAddItems(null);
            adminAddItems.setVisible(true);
        });
    }
}
