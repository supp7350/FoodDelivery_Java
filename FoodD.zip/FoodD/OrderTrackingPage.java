import java.awt.*;
import java.awt.event.*;

public class OrderTrackingPage extends JFrame {
    private JLabel itemsLabel;
    private JLabel totalCostLabel;
    private JLabel totalItemsLabel;
    private JLabel statusLabel;
    private JButton trackOrderButton;

    public OrderTrackingPage(String orderedItems, double totalCost, int totalItems, String status) {
        setTitle("Track Your Order");
        setSize(700, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("My Orders");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 5;
        mainPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;

        // Items label with box icon
        ImageIcon boxIcon = new ImageIcon(getClass().getResource("/assets/box.png"));
        itemsLabel = new JLabel(orderedItems, boxIcon, JLabel.LEADING);
        itemsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.weightx = 0.5;
        mainPanel.add(itemsLabel, gbc);

        // Total cost label
        totalCostLabel = new JLabel(String.format("$%.2f", totalCost));
        totalCostLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridx = 1;
        gbc.weightx = 0.1;
        mainPanel.add(totalCostLabel, gbc);

        // Total items label
        totalItemsLabel = new JLabel("Items: " + totalItems);
        totalItemsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridx = 2;
        gbc.weightx = 0.1;
        mainPanel.add(totalItemsLabel, gbc);

        // Status label
        statusLabel = new JLabel(status);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        statusLabel.setForeground(new Color(220, 20, 60)); // Crimson red for better match
        gbc.gridx = 3;
        gbc.weightx = 0.2;
        mainPanel.add(statusLabel, gbc);

        // Track Order button
        trackOrderButton = new JButton("Track Order");
        trackOrderButton.setBackground(new Color(255, 192, 203)); // Slightly softer pink
        trackOrderButton.setForeground(Color.BLACK);
        trackOrderButton.setFocusPainted(false);
        trackOrderButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        gbc.gridx = 4;
        gbc.weightx = 0.1;
        mainPanel.add(trackOrderButton, gbc);

        // Add action listener to Track Order button
        trackOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Simulate fetching updated order status from admin
                String currentStatus = statusLabel.getText();
                if (currentStatus.equalsIgnoreCase("Food Processing")) {
                    updateStatus("Out for Delivery");
                } else {
                    updateStatus("Food Processing");
                }
                JOptionPane.showMessageDialog(OrderTrackingPage.this,
                        "Order status updated to: " + statusLabel.getText(),
                        "Order Status",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        add(mainPanel);
    }

    // Method to update the status label dynamically
    public void updateStatus(String newStatus) {
        statusLabel.setText(newStatus);
        if (newStatus.equalsIgnoreCase("Out for Delivery")) {
            statusLabel.setForeground(new Color(34, 139, 34)); // Forest green
        } else {
            statusLabel.setForeground(new Color(220, 20, 60)); // Crimson red
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            String orderedItems = "Greek salad x 2, Peri Peri Rolls x 3";
            double totalCost = 65.00;
            int totalItems = 5;
            String status = "Food Processing";
            OrderTrackingPage trackingPage = new OrderTrackingPage(orderedItems, totalCost, totalItems, status);
            trackingPage.setVisible(true);
        });
    }
}
=======
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class OrderTrackingPage extends JFrame {
    private JLabel itemsLabel;
    private JLabel totalCostLabel;
    private JLabel totalItemsLabel;
    private JLabel statusLabel;
    private JButton trackOrderButton;

    public OrderTrackingPage(String orderedItems, double totalCost, int totalItems, String status) {
        setTitle("Track Your Order");
        setSize(700, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("My Orders");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 5;
        mainPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;

        // Items label with box icon
        ImageIcon boxIcon = new ImageIcon(getClass().getResource("/assets/box.png"));
        itemsLabel = new JLabel(orderedItems, boxIcon, JLabel.LEADING);
        itemsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.weightx = 0.5;
        mainPanel.add(itemsLabel, gbc);

        // Total cost label
        totalCostLabel = new JLabel(String.format("$%.2f", totalCost));
        totalCostLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridx = 1;
        gbc.weightx = 0.1;
        mainPanel.add(totalCostLabel, gbc);

        // Total items label
        totalItemsLabel = new JLabel("Items: " + totalItems);
        totalItemsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridx = 2;
        gbc.weightx = 0.1;
        mainPanel.add(totalItemsLabel, gbc);

        // Status label
        statusLabel = new JLabel(status);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        statusLabel.setForeground(new Color(220, 20, 60)); // Crimson red for better match
        gbc.gridx = 3;
        gbc.weightx = 0.2;
        mainPanel.add(statusLabel, gbc);

        // Track Order button
        trackOrderButton = new JButton("Track Order");
        trackOrderButton.setBackground(new Color(255, 192, 203)); // Slightly softer pink
        trackOrderButton.setForeground(Color.BLACK);
        trackOrderButton.setFocusPainted(false);
        trackOrderButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        gbc.gridx = 4;
        gbc.weightx = 0.1;
        mainPanel.add(trackOrderButton, gbc);

        // Add action listener to Track Order button
        trackOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Simulate fetching updated order status from admin
                String currentStatus = statusLabel.getText();
                if (currentStatus.equalsIgnoreCase("Food Processing")) {
                    updateStatus("Out for Delivery");
                } else {
                    updateStatus("Food Processing");
                }
                JOptionPane.showMessageDialog(OrderTrackingPage.this,
                        "Order status updated to: " + statusLabel.getText(),
                        "Order Status",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        add(mainPanel);
    }

    // Method to update the status label dynamically
    public void updateStatus(String newStatus) {
        statusLabel.setText(newStatus);
        if (newStatus.equalsIgnoreCase("Out for Delivery")) {
            statusLabel.setForeground(new Color(34, 139, 34)); // Forest green
        } else {
            statusLabel.setForeground(new Color(220, 20, 60)); // Crimson red
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            String orderedItems = "Greek salad x 2, Peri Peri Rolls x 3";
            double totalCost = 65.00;
            int totalItems = 5;
            String status = "Food Processing";
            OrderTrackingPage trackingPage = new OrderTrackingPage(orderedItems, totalCost, totalItems, status);
            trackingPage.setVisible(true);
        });
    }
}
