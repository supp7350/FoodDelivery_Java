import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;

public class TrackOrder extends JFrame {
    private JPanel orderPanel;
    private JLabel statusLabel;
    private JButton trackOrderButton;

    // Sample order item class
    class OrderItem {
        String name;
        double price;
        int quantity;

        public OrderItem(String name, double price, int quantity) {
            this.name = name;
            this.price = price;
            this.quantity = quantity;
        }

        public double getTotalPrice() {
            return price * quantity;
        }
    }

    private List<OrderItem> orderItems;
    private String orderStatus; // "Processing" or "Out to Reach"

    public TrackOrder(List<OrderItem> items, String status) {
        this.orderItems = (items != null) ? items : new ArrayList<>();
        this.orderStatus = (status != null) ? status : "Processing";

        setTitle("My Orders");
        setSize(700, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        orderPanel = new JPanel();
        orderPanel.setLayout(new BoxLayout(orderPanel, BoxLayout.X_AXIS));
        orderPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        orderPanel.setBackground(Color.WHITE);

        // Add order items info horizontally
        for (OrderItem item : orderItems) {
            JPanel itemPanel = new JPanel();
            itemPanel.setLayout(new BoxLayout(itemPanel, BoxLayout.Y_AXIS));
            itemPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            itemPanel.setBackground(Color.WHITE);

            JLabel nameLabel = new JLabel(item.name + " x " + item.quantity);
            nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            itemPanel.add(nameLabel);

            JLabel priceLabel = new JLabel("₹" + String.format("%.2f", item.price));
            priceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            itemPanel.add(priceLabel);

            JLabel totalLabel = new JLabel("Total: ₹" + String.format("%.2f", item.getTotalPrice()));
            totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            itemPanel.add(totalLabel);

            orderPanel.add(itemPanel);
            orderPanel.add(Box.createHorizontalStrut(20));
        }

        // Status label
        statusLabel = new JLabel("Status: " + orderStatus);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        if (orderStatus.equalsIgnoreCase("Processing")) {
            statusLabel.setForeground(new Color(255, 69, 0)); // OrangeRed
        } else if (orderStatus.equalsIgnoreCase("Out to Reach")) {
            statusLabel.setForeground(new Color(34, 139, 34)); // ForestGreen
        } else {
            statusLabel.setForeground(Color.BLACK);
        }

        // Track Order button
        trackOrderButton = new JButton("Track Order");
        trackOrderButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        trackOrderButton.setBackground(new Color(255, 182, 193)); // LightPink
        trackOrderButton.setForeground(Color.BLACK);
        trackOrderButton.setFocusPainted(false);
        trackOrderButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        trackOrderButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        trackOrderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open OrderTrackingPage or show placeholder
                try {
                    Class<?> clazz = Class.forName("OrderTrackingPage");
                    JFrame trackingPage = (JFrame) clazz.getDeclaredConstructor().newInstance();
                    trackingPage.setVisible(true);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(TrackOrder.this,
                        "Order tracking page is not available.",
                        "Info",
                        JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Bottom panel for status and button horizontally
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.add(statusLabel);
        bottomPanel.add(Box.createHorizontalStrut(20));
        bottomPanel.add(trackOrderButton);

        add(orderPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            List<OrderItem> sampleItems = new ArrayList<>();
            sampleItems.add(new TrackOrder(null, null).new OrderItem("Greek salad", 20.0, 2));
            sampleItems.add(new TrackOrder(null, null).new OrderItem("Peri Peri Rolls", 15.0, 3));

            TrackOrder orderPage = new TrackOrder(sampleItems, "Processing");
            orderPage.setVisible(true);
        });
    }
}
