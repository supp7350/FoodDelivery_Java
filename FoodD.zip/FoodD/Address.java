import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.*;

public class Address extends JFrame {
    private JTextField firstNameField;
    private JTextField emailField;
    private JTextField streetField;
    private JTextField cityField;
    private JTextField stateField;
    private JTextField zipCodeField;
    private JTextField countryField;
    private JTextField phoneField;
    private JTextField pincodeField;
    private JButton placeOrderButton;

    public Address() {
        setTitle("Delivery Address Information");
        setSize(700, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Left panel for delivery info form
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Delivery Information");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        formPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;

        // First Name
        gbc.gridy++;
        gbc.gridx = 0;
        firstNameField = new JTextField("Enter your Name", 32);
        addPlaceholderStyle(firstNameField);
        formPanel.add(firstNameField, gbc);
        addPlaceholderFocusListener(firstNameField, "Enter your Name");

        // Email
        gbc.gridy++;
        gbc.gridx = 0;
        emailField = new JTextField("Enter your Email", 32);
        addPlaceholderStyle(emailField);
        formPanel.add(emailField, gbc);
        addPlaceholderFocusListener(emailField, "Enter your Email");

        // Street (Lane No.)
        gbc.gridy++;
        gbc.gridx = 0;
        streetField = new JTextField("Enter Lane No.", 32);
        addPlaceholderStyle(streetField);
        formPanel.add(streetField, gbc);
        addPlaceholderFocusListener(streetField, "Lane No.");

        // City (Street Name)
        gbc.gridy++;
        gbc.gridx = 0;
        cityField = new JTextField("Enter Street Name", 32);
        addPlaceholderStyle(cityField);
        formPanel.add(cityField, gbc);
        addPlaceholderFocusListener(cityField, "Street Name");

        // State (Locality)
        gbc.gridy++;
        gbc.gridx = 0;
        stateField = new JTextField("Enter Locality", 32);
        addPlaceholderStyle(stateField);
        formPanel.add(stateField, gbc);
        addPlaceholderFocusListener(stateField, "Locality");

        // Zip Code (City)
        gbc.gridy++;
        gbc.gridx = 0;
        zipCodeField = new JTextField("Enter City", 32);
        addPlaceholderStyle(zipCodeField);
        formPanel.add(zipCodeField, gbc);
        addPlaceholderFocusListener(zipCodeField, "City");

        // Country (State)
        gbc.gridy++;
        gbc.gridx = 0;
        countryField = new JTextField("Enter State", 32);
        addPlaceholderStyle(countryField);
        formPanel.add(countryField, gbc);
        addPlaceholderFocusListener(countryField, "State");

        // Phone (Country)
        gbc.gridy++;
        gbc.gridx = 0;
        phoneField = new JTextField("Enter Country", 32);
        addPlaceholderStyle(phoneField);
        formPanel.add(phoneField, gbc);
        addPlaceholderFocusListener(phoneField, "Country");

        // Pincode
        gbc.gridy++;
        gbc.gridx = 0;
        pincodeField = new JTextField("Enter Pincode", 32);
        addPlaceholderStyle(pincodeField);
        formPanel.add(pincodeField, gbc);
        addPlaceholderFocusListener(pincodeField, "Pincode");

        mainPanel.add(formPanel, BorderLayout.WEST);

        // Right panel for cart totals and place order button
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

        JLabel cartTotalsLabel = new JLabel("Cart Totals");
        cartTotalsLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        cartTotalsLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightPanel.add(cartTotalsLabel);

        rightPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel subtotalLabel = new JLabel("Subtotal: ₹0.00");
        subtotalLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtotalLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightPanel.add(subtotalLabel);

        JLabel deliveryFeeLabel = new JLabel("Delivery Fee: ₹50.00");
        deliveryFeeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        deliveryFeeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightPanel.add(deliveryFeeLabel);

        rightPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        JSeparator separator = new JSeparator(SwingConstants.HORIZONTAL);
        separator.setMaximumSize(new Dimension(200, 1));
        rightPanel.add(separator);

        rightPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel totalLabel = new JLabel("Total: ₹0.00");
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        totalLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightPanel.add(totalLabel);

        rightPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        placeOrderButton = new JButton("Place Order");
        placeOrderButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        placeOrderButton.setBackground(new Color(255, 69, 0));
        placeOrderButton.setForeground(Color.WHITE);
        placeOrderButton.setFocusPainted(false);
        placeOrderButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        placeOrderButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        placeOrderButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        placeOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open OrderSuccessPage instead of simple dialog
                if (firstNameField.getText().equals("Enter your Name") || firstNameField.getText().isEmpty() ||
                    emailField.getText().equals("Enter your Email") || emailField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(Address.this, "Please fill in all required fields (Name, Email).", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                OrderSuccessPage successPage = new OrderSuccessPage();
                successPage.setVisible(true);
                dispose();
            }
        });

        rightPanel.add(placeOrderButton);

        mainPanel.add(rightPanel, BorderLayout.EAST);

        add(mainPanel);
    }

    private void placeOrder() {
        // Simple validation example
        if (firstNameField.getText().equals("Enter your Name") || firstNameField.getText().isEmpty() ||
            emailField.getText().equals("Enter your Email") || emailField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields (Name, Email).", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this, "Order placed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        dispose();
    }

    private void addPlaceholderStyle(JTextComponent textComponent) {
        textComponent.setForeground(Color.GRAY);
        textComponent.setFont(new Font("Arial", Font.ITALIC, 16));
    }

    private void removePlaceholderStyle(JTextComponent textComponent) {
        textComponent.setForeground(Color.BLACK);
        textComponent.setFont(new Font("Arial", Font.PLAIN, 16));
    }

    private void addPlaceholderFocusListener(JTextComponent textComponent, String placeholder) {
        textComponent.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textComponent.getText().equals(placeholder)) {
                    textComponent.setText("");
                    removePlaceholderStyle(textComponent);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textComponent.getText().isEmpty()) {
                    addPlaceholderStyle(textComponent);
                    textComponent.setText(placeholder);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Address addressPage = new Address();
            addressPage.setVisible(true);
        });
    }
}
