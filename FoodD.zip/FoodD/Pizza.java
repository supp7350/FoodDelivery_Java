import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public class Pizza extends JFrame {
    
    // Vegetarian Pizzas with prices
    private Map<String, Double> vegPizzas = new HashMap<>();
    
    // Non-Vegetarian Pizzas with prices
    private Map<String, Double> nonVegPizzas = new HashMap<>();
    
    // Lists to store selected items
    private List<String> selectedItems = new ArrayList<>();
    
    public Pizza() {
        // Initialize vegetarian pizzas with prices
        vegPizzas.put("Margherita Pizza", 150.0);
        vegPizzas.put("Paneer Pizza", 180.0);
        vegPizzas.put("Veggie Supreme Pizza", 200.0);
        vegPizzas.put("Mushroom Pizza", 170.0);
        vegPizzas.put("Corn & Cheese Pizza", 160.0);
        vegPizzas.put("Capsicum Pizza", 140.0);
        vegPizzas.put("Onion Pizza", 130.0);
        vegPizzas.put("Green Peas Pizza", 160.0);
        vegPizzas.put("Mixed Veg Pizza", 190.0);
        vegPizzas.put("Jalapeno Pizza", 175.0);
        
        // Initialize non-vegetarian pizzas with prices
        nonVegPizzas.put("Chicken Pizza", 200.0);
        nonVegPizzas.put("Chicken Tikka Pizza", 220.0);
        nonVegPizzas.put("Pepperoni Pizza", 230.0);
        nonVegPizzas.put("Sausage Pizza", 210.0);
        nonVegPizzas.put("Mutton Pizza", 250.0);
        nonVegPizzas.put("Fish Pizza", 240.0);
        nonVegPizzas.put("Egg Pizza", 180.0);
        nonVegPizzas.put("Chicken & Mushroom Pizza", 235.0);
        nonVegPizzas.put("Barbeque Chicken Pizza", 245.0);
        nonVegPizzas.put("Prawn Pizza", 260.0);
        
        setTitle("Pizza Menu");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Create main panel with gradient background
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                Color color1 = new Color(255, 248, 220);
                Color color2 = new Color(255, 228, 181);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Title label with enhanced styling
        JLabel titleLabel = new JLabel("DELICIOUS PIZZA MENU", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        titleLabel.setForeground(new Color(139, 69, 19));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        titleLabel.setVerticalAlignment(SwingConstants.TOP);
        
        // Create content panel with enhanced styling
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setOpaque(false);
        
        // Add vegetarian pizzas section with enhanced styling
        contentPanel.add(createAttractivePizzaSection("VEGETARIAN PIZZAS", vegPizzas, new Color(144, 238, 144, 200)));
        
        // Add spacing between sections
        contentPanel.add(Box.createRigidArea(new Dimension(0, 40)));
        
        // Add non-vegetarian pizzas section with enhanced styling
        contentPanel.add(createAttractivePizzaSection("NON-VEGETARIAN PIZZAS", nonVegPizzas, new Color(255, 182, 193, 200)));
        
        // Add buttons panel with enhanced styling
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonsPanel.setOpaque(false);
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        JButton viewCartButton = new JButton("View Cart");
        styleButton(viewCartButton, new Color(34, 139, 34));
        viewCartButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showCart();
            }
        });
        
        JButton backButton = new JButton("Back to Main Menu");
        styleButton(backButton, new Color(30, 144, 255));
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close this window
            }
        });
        
        buttonsPanel.add(viewCartButton);
        buttonsPanel.add(backButton);
        
        // Add components to main panel
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        mainPanel.add(new JScrollPane(contentPanel), BorderLayout.CENTER);
        mainPanel.add(buttonsPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private void styleButton(JButton button, Color bgColor) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 18));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
        
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
    }
    
    private JPanel createAttractivePizzaSection(String title, Map<String, Double> pizzas, Color bgColor) {
        JPanel sectionPanel = new JPanel();
        sectionPanel.setLayout(new BorderLayout());
        sectionPanel.setBackground(bgColor);
        sectionPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(100, 100, 100), 3, true), 
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        // Create title label for section
        JLabel sectionTitleLabel = new JLabel(title, SwingConstants.CENTER);
        sectionTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        sectionTitleLabel.setForeground(new Color(139, 69, 19));
        sectionTitleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        sectionPanel.add(sectionTitleLabel, BorderLayout.NORTH);
        
        // Create panel for items with vertical layout
        JPanel itemsPanel = new JPanel();
        itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS));
        itemsPanel.setBackground(new Color(bgColor.getRed(), bgColor.getGreen(), bgColor.getBlue(), 220));
        itemsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Add items to the panel vertically
        for (Map.Entry<String, Double> entry : pizzas.entrySet()) {
            JPanel itemPanel = new JPanel(new GridBagLayout());
            itemPanel.setBackground(new Color(bgColor.getRed(), bgColor.getGreen(), bgColor.getBlue(), 220));
            itemPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 100, 100), 1, true),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
            ));
            itemPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
            itemPanel.setCursor(new Cursor(Cursor.HAND_CURSOR));
            
            // Add hover effect to item panel
            itemPanel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    itemPanel.setBackground(new Color(bgColor.getRed(), bgColor.getGreen(), bgColor.getBlue(), 255));
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    itemPanel.setBackground(new Color(bgColor.getRed(), bgColor.getGreen(), bgColor.getBlue(), 220));
                }
            });
            
            GridBagConstraints gbc = new GridBagConstraints();
            
            // Create checkbox for selection
            JCheckBox itemCheckBox = new JCheckBox();
            itemCheckBox.setBackground(new Color(bgColor.getRed(), bgColor.getGreen(), bgColor.getBlue(), 220));
            itemCheckBox.setFont(new Font("Segoe UI", Font.BOLD, 16));
            itemCheckBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (itemCheckBox.isSelected()) {
                        selectedItems.add(entry.getKey() + " - ₹" + String.format("%.0f", entry.getValue()));
                    } else {
                        selectedItems.remove(entry.getKey() + " - ₹" + String.format("%.0f", entry.getValue()));
                    }
                }
            });
            
            // Create labels for item name and price
            JLabel nameLabel = new JLabel(entry.getKey());
            nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
            nameLabel.setForeground(Color.BLACK);
            
            JLabel priceLabel = new JLabel("₹" + String.format("%.0f", entry.getValue()));
            priceLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
            priceLabel.setForeground(new Color(0, 100, 0));
            
            // Add components to item panel
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 0, 0, 15);
            itemPanel.add(itemCheckBox, gbc);
            
            gbc.gridx = 1;
            gbc.insets = new Insets(0, 0, 0, 0);
            gbc.weightx = 1.0;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            itemPanel.add(nameLabel, gbc);
            
            gbc.gridx = 2;
            gbc.weightx = 0;
            gbc.fill = GridBagConstraints.NONE;
            gbc.insets = new Insets(0, 20, 0, 0);
            itemPanel.add(priceLabel, gbc);
            
            itemsPanel.add(itemPanel);
            itemsPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        }
        
        // Wrap items panel in a scroll pane
        JScrollPane scrollPane = new JScrollPane(itemsPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getViewport().setBackground(bgColor);
        
        sectionPanel.add(scrollPane, BorderLayout.CENTER);
        return sectionPanel;
    }
    
    private void showCart() {
        // Open the cart page with selected items
        new Cartpage(selectedItems).setVisible(true);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
                new Pizza().setVisible(true);
            }
        });
    }
}
