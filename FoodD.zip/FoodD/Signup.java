import javax.swing.*;  
import javax.swing.text.JTextComponent;
import java.awt.*;  
import java.awt.event.*;  
import java.io.File;  
import java.io.IOException;  
import javax.imageio.ImageIO;  

public class Signup extends JFrame {  
    private JTextField usernameField;  
    private JTextField ageField;  
    private JTextField countryField;  
    private JTextField stateField;  
    private JTextField addressField;  
    private JPasswordField passwordField;  
    private JPasswordField confirmPasswordField;  
    private JButton signupButton;  
    private JButton goToLoginButton;  
    private Image backgroundImage;  

    public Signup() {  
        setTitle("Food Delivery App - Signup");  
        setSize(600, 600);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        setLocationRelativeTo(null);  

        try {  
            backgroundImage = ImageIO.read(new File("C:\\Users\\INDIA\\Desktop\\FoodD\\assets\\BG3.jpg"));  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  

        BackgroundPanel backgroundPanel = new BackgroundPanel();  
        backgroundPanel.setLayout(new GridBagLayout());  
        setContentPane(backgroundPanel);  

        GridBagConstraints gbc = new GridBagConstraints();  
        gbc.insets = new Insets(10, 10, 10, 10);  
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 0;  
        gbc.gridwidth = 2;  

        usernameField = new JTextField("Enter the Username");  
        addPlaceholderStyle(usernameField);  
        backgroundPanel.add(usernameField, gbc);  

        gbc.gridy++;  
        ageField = new JTextField("Enter the Age");  
        addPlaceholderStyle(ageField);  
        backgroundPanel.add(ageField, gbc);  

        gbc.gridy++;  
        countryField = new JTextField("Enter the Country");  
        addPlaceholderStyle(countryField);  
        backgroundPanel.add(countryField, gbc);  

        gbc.gridy++;  
        stateField = new JTextField("Enter the State");  
        addPlaceholderStyle(stateField);  
        backgroundPanel.add(stateField, gbc);  

        gbc.gridy++;  
        addressField = new JTextField("Enter the Address");  
        addPlaceholderStyle(addressField);  
        backgroundPanel.add(addressField, gbc);  

        gbc.gridy++;  
        passwordField = new JPasswordField("Enter the Password");  
        addPlaceholderStyle(passwordField);  
        backgroundPanel.add(passwordField, gbc);  

        gbc.gridy++;  
        confirmPasswordField = new JPasswordField("Confirm the Password");  
        addPlaceholderStyle(confirmPasswordField);  
        backgroundPanel.add(confirmPasswordField, gbc);  

        gbc.gridy++;  
        gbc.gridwidth = 1;  
        gbc.gridx = 0;  
        signupButton = new JButton("Sign Up");  
        signupButton.setBackground(new Color(70, 130, 180)); // Steel Blue  
        signupButton.setForeground(Color.WHITE);  
        signupButton.setFont(new Font("Arial", Font.BOLD, 18));  
        backgroundPanel.add(signupButton, gbc);  

        gbc.gridx = 1;  
        goToLoginButton = new JButton("Go to Login");  
        goToLoginButton.setBackground(new Color(34, 139, 34)); // Forest Green  
        goToLoginButton.setForeground(Color.WHITE);  
        goToLoginButton.setFont(new Font("Arial", Font.BOLD, 18));  
        backgroundPanel.add(goToLoginButton, gbc);  

        // Add focus listeners for placeholders  
        addPlaceholderFocusListener(usernameField, "Enter the Username");  
        addPlaceholderFocusListener(ageField, "Enter the Age");  
        addPlaceholderFocusListener(countryField, "Enter the Country");  
        addPlaceholderFocusListener(stateField, "Enter the State");  
        addPlaceholderFocusListener(addressField, "Enter the Address");  
        addPlaceholderFocusListener(passwordField, "Enter the Password");  
        addPlaceholderFocusListener(confirmPasswordField, "Confirm the Password");  

        // Add action listeners for buttons  
        signupButton.addActionListener(new ActionListener() {  
            @Override  
            public void actionPerformed(ActionEvent e) {  
                JOptionPane.showMessageDialog(Signup.this, "Sign Up button clicked!");  
            }  
        });  

        goToLoginButton.addActionListener(new ActionListener() {  
            @Override  
            public void actionPerformed(ActionEvent e) {  
                dispose();  
                new Login().setVisible(true);  
            }  
        });  
    }  

    private void addPlaceholderStyle(JTextComponent textComponent) {  
        textComponent.setForeground(Color.GRAY);  
        textComponent.setFont(new Font("Arial", Font.ITALIC, 16));  
    }  

    private void removePlaceholderStyle(JTextComponent textComponent) {  
        textComponent.setForeground(Color.BLACK);  
        textComponent.setFont(new Font("Arial", Font.PLAIN, 16));  
    }  

    private void addPlaceholderFocusListener(JTextComponent textComponent, String placeholder) {  
        textComponent.addFocusListener(new FocusAdapter() {  
            @Override  
            public void focusGained(FocusEvent e) {  
                if (textComponent.getText().equals(placeholder)) {  
                    textComponent.setText("");  
                    removePlaceholderStyle(textComponent);  
                    if (textComponent instanceof JPasswordField) {  
                        ((JPasswordField) textComponent).setEchoChar('•');  
                    }  
                }  
            }  

            @Override  
            public void focusLost(FocusEvent e) {  
                if (textComponent.getText().isEmpty()) {  
                    addPlaceholderStyle(textComponent);  
                    textComponent.setText(placeholder);  
                    if (textComponent instanceof JPasswordField) {  
                        ((JPasswordField) textComponent).setEchoChar((char) 0);  
                    }  
                }  
            }  
        });  
        if (textComponent instanceof JPasswordField) {  
            ((JPasswordField) textComponent).setEchoChar((char) 0);  
        }  
    }  

    private class BackgroundPanel extends JPanel {  
        @Override  
        protected void paintComponent(Graphics g) {  
            super.paintComponent(g);  
            if (backgroundImage != null) {  
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);  
            }  
        }  
    }  

    public static void main(String[] args) {  
        SwingUtilities.invokeLater(new Runnable() {  
            @Override  
            public void run() {  
                new Signup().setVisible(true);  
            }  
        });  
    }  
}
