import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.io.File;
import javax.imageio.ImageIO;

public class List extends JFrame {
    // Food item data class
    class FoodItem {
        String name;
        String type;
        double cost;

        public FoodItem(String name, String type, double cost) {
            this.name = name;
            this.type = type;
            this.cost = cost;
        }
    }

    private JPanel itemsPanel;
    private java.util.List<FoodItem> foodItems;
    
    // Custom background panel class with transparency
    class BackgroundPanel extends JPanel {
        private Image backgroundImage;
        private float transparency = 0.3f; // 30% opacity (70% transparent)
        
        public BackgroundPanel(String imagePath) {
            try {
                backgroundImage = ImageIO.read(new File(imagePath));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                // Create a Graphics2D object for better control
                Graphics2D g2d = (Graphics2D) g.create();
                
                // Set the composite to apply transparency
                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, transparency));
                
                // Draw the image with transparency
                g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                
                // Dispose the graphics object
                g2d.dispose();
            }
        }
        
        // Optional: method to adjust transparency if needed
        public void setTransparency(float transparency) {
            this.transparency = Math.max(0.0f, Math.min(1.0f, transparency));
            repaint();
        }
    }

    public List(java.util.List<FoodItem> foodItems) {
        this.foodItems = (foodItems != null) ? foodItems : new ArrayList<>();

        setTitle("Admin Food Items List");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create background panel with the specified image
        BackgroundPanel backgroundPanel = new BackgroundPanel("C:\\Users\\INDIA\\Desktop\\FoodD\\assets\\3472ed47-271a-4a4d-945c-8865c47cf81b.jpeg");
        backgroundPanel.setLayout(new BorderLayout());
        
        itemsPanel = new JPanel();
        itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS));
        itemsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        itemsPanel.setOpaque(false); // Make panel transparent to show background

        JScrollPane scrollPane = new JScrollPane(itemsPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);

        backgroundPanel.add(scrollPane, BorderLayout.CENTER);
        add(backgroundPanel, BorderLayout.CENTER);

        populateItems();
    }

    private void populateItems() {
        itemsPanel.removeAll();

        for (FoodItem item : foodItems) {
            JPanel itemRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
            itemRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            itemRow.setBackground(new Color(245, 245, 245));
            itemRow.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));

            JLabel nameLabel = new JLabel(item.name);
            nameLabel.setPreferredSize(new Dimension(250, 30));
            nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            itemRow.add(nameLabel);

            JLabel typeLabel = new JLabel(item.type);
            typeLabel.setPreferredSize(new Dimension(150, 30));
            typeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            itemRow.add(typeLabel);

            JLabel costLabel = new JLabel("₹" + String.format("%.2f", item.cost));
            costLabel.setPreferredSize(new Dimension(100, 30));
            costLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            itemRow.add(costLabel);

            JButton removeButton = new JButton("✖");
            removeButton.setPreferredSize(new Dimension(50, 30));
            removeButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
            removeButton.setForeground(Color.RED);
            removeButton.setFocusPainted(false);
            removeButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            removeButton.setToolTipText("Remove Item");
            removeButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    foodItems.remove(item);
                    populateItems();
                    JOptionPane.showMessageDialog(List.this, "Item removed successfully", "Info", JOptionPane.INFORMATION_MESSAGE);
                }
            });
            itemRow.add(removeButton);

            itemsPanel.add(itemRow);
            itemsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        }

        itemsPanel.revalidate();
        itemsPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            java.util.List<FoodItem> sampleItems = new ArrayList<>();
            List listInstance = new List(null);
            sampleItems.add(listInstance.new FoodItem("Margherita Pizza", "Pizza", 150.0));
            sampleItems.add(listInstance.new FoodItem("Chicken Burger", "Burger", 160.0));
            sampleItems.add(listInstance.new FoodItem("Paneer Roll", "Rolls", 120.0));

            List adminFoodListPage = new List(sampleItems);
            adminFoodListPage.setVisible(true);
        });
    }
}
