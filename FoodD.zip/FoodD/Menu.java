import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class Menu extends JFrame {
    private JPanel mainPanel;
    
    public Menu() {
        setTitle("Food Menu");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Create main panel with background image
        mainPanel = new JPanel(new BorderLayout()) {
            private Image backgroundImage;
            
            {
                try {
                    backgroundImage = new ImageIcon("assets/Background4.jpg").getImage();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    // Draw the background image scaled to fit the panel
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                } else {
                    // Fallback gradient if image fails to load
                    Graphics2D g2d = (Graphics2D) g;
                    g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                    int w = getWidth();
                    int h = getHeight();
                    Color color1 = new Color(255, 248, 220);
                    Color color2 = new Color(255, 200, 100);
                    GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
                    g2d.setPaint(gp);
                    g2d.fillRect(0, 0, w, h);
                }
            }
        };
        
        // Title label
        JLabel titleLabel = new JLabel("Let's Have some Choices....", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 48));
        titleLabel.setForeground(new Color(139, 69, 19));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(30, 0, 30, 0));
        titleLabel.setVerticalAlignment(SwingConstants.TOP);
        
        // Create panel for food category buttons
        JPanel categoriesPanel = new JPanel(new GridBagLayout());
        categoriesPanel.setOpaque(false);
        categoriesPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 50, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20);
        gbc.fill = GridBagConstraints.BOTH;
        
        // Create buttons for each food category
        JButton pizzaButton = createCategoryButton("Pizza", "assets/pizza.jpeg", new Color(255, 165, 0));
        pizzaButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openCategory("Pizza");
            }
        });
        
        JButton burgerButton = createCategoryButton("Burger", "assets/Burger.jpg", new Color(210, 105, 30));
        burgerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openCategory("Burger");
            }
        });
        
        JButton sabjiButton = createCategoryButton("Sabji", "assets/sabji.jpeg", new Color(50, 205, 50));
        sabjiButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openCategory("Sabji");
            }
        });
        
        JButton rollsButton = createCategoryButton("Rolls", "assets/rolls.jpg", new Color(255, 105, 180));
        rollsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openCategory("Rolls");
            }
        });
        
        JButton streetFoodButton = createCategoryButton("Street Food", "assets/Street_food.jpeg", new Color(255, 99, 71));
        streetFoodButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openCategory("Street_food");
            }
        });
        
        JButton desertButton = createCategoryButton("Desert", "assets/Desert.jpeg", new Color(255, 192, 203));
        desertButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openCategory("Desert");
            }
        });
        
        // Add buttons to the grid
        gbc.gridx = 0; gbc.gridy = 0;
        categoriesPanel.add(pizzaButton, gbc);
        
        gbc.gridx = 1; gbc.gridy = 0;
        categoriesPanel.add(burgerButton, gbc);
        
        gbc.gridx = 2; gbc.gridy = 0;
        categoriesPanel.add(sabjiButton, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        categoriesPanel.add(rollsButton, gbc);
        
        gbc.gridx = 1; gbc.gridy = 1;
        categoriesPanel.add(streetFoodButton, gbc);
        
        gbc.gridx = 2; gbc.gridy = 1;
        categoriesPanel.add(desertButton, gbc);
        
        // Add components to main panel
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        mainPanel.add(categoriesPanel, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JButton createCategoryButton(String categoryName, String imagePath, Color buttonColor) {
        JButton button = new JButton(categoryName);
        button.setPreferredSize(new Dimension(250, 200));
        button.setFont(new Font("Segoe UI", Font.BOLD, 24));
        button.setForeground(Color.WHITE);
        button.setBackground(buttonColor);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(buttonColor.darker());
            }
        
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(buttonColor);
            }
        });
        
        // Try to add image to button
        try {
            ImageIcon icon = new ImageIcon(imagePath);
            Image img = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            button.setIcon(new ImageIcon(img));
            button.setVerticalTextPosition(SwingConstants.BOTTOM);
            button.setHorizontalTextPosition(SwingConstants.CENTER);
        } catch (Exception e) {
            System.out.println("Could not load image for " + categoryName);
        }
        
        return button;
    }
    
    private void openCategory(String categoryName) {
        try {
            // Close the current menu window
            this.dispose();
            
            // Open the appropriate category window
            switch (categoryName) {
                case "Pizza":
                    new Pizza().setVisible(true);
                    break;
                case "Burger":
                    new Burger().setVisible(true);
                    break;
                case "Sabji":
                    new Sabji().setVisible(true);
                    break;
                case "Rolls":
                    new Rolls().setVisible(true);
                    break;
                case "Street_food":
                    new Street_food().setVisible(true);
                    break;
                case "Desert":
                    new Desert().setVisible(true);
                    break;
                default:
                    JOptionPane.showMessageDialog(this, "Category not found: " + categoryName);
                    break;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error opening category: " + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
                new Menu().setVisible(true);
            }
        });
    }
}
