import javax.swing.*;
import java.awt.*;

public class WelcomePage extends JFrame {

    public WelcomePage() {
        setTitle("Yumm.. Masala");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Application name label
        JLabel titleLabel = new JLabel("Yumm.. Masala", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 28));
        titleLabel.setForeground(new Color(255, 69, 0)); // Orange-Red color
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(titleLabel, BorderLayout.NORTH);

        // Panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2, 1, 10, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 150, 150, 150));

        // HUNGRY MAN button
        JButton hungryManButton = new JButton("HUNGRY MAN");
        hungryManButton.setBackground(new Color(60, 179, 113)); // Medium Sea Green
        hungryManButton.setForeground(Color.WHITE);
        hungryManButton.setFont(new Font("Arial", Font.BOLD, 24));
        hungryManButton.setFocusPainted(false);

        // SELLER MAN button
        JButton sellerManButton = new JButton("SELLER MAN");
        sellerManButton.setBackground(new Color(70, 130, 180)); // Steel Blue
        sellerManButton.setForeground(Color.WHITE);
        sellerManButton.setFont(new Font("Arial", Font.BOLD, 24));
        sellerManButton.setFocusPainted(false);

        buttonPanel.add(hungryManButton);
        buttonPanel.add(sellerManButton);

        add(buttonPanel, BorderLayout.CENTER);

        // Add action listeners for buttons
        hungryManButton.addActionListener(e -> {
            // Open Home or Menu page for hungry user
            Home homePage = new Home();
            homePage.setVisible(true);
            this.dispose();
        });

        sellerManButton.addActionListener(e -> {
            // Open AdminAddItems page for seller/admin
            AdminAddItems adminPage = new AdminAddItems(null);
            adminPage.setVisible(true);
            this.dispose();
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            WelcomePage welcomePage = new WelcomePage();
            welcomePage.setVisible(true);
        });
    }
}
