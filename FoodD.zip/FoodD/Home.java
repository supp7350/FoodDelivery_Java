import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.*;
import java.io.*;
import javax.imageio.ImageIO;

public class Home extends JFrame {

    private BufferedImage backgroundImage;

    public Home() {
        setTitle("Food Delivery App - Home");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        try {
            backgroundImage = ImageIO.read(new File("C:\\Users\\INDIA\\Desktop\\FoodD\\assets\\BG2.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(null);

        // First prompt - larger font, HTML tags allowed
        JLabel prompt1 = new JLabel("<html><div style='text-align:center;'>Lookin for the <b>Delicious Meal!!!!</b> Hmm</div></html>");
        prompt1.setForeground(Color.WHITE);
        prompt1.setFont(new Font("Arial", Font.BOLD, 28));
        prompt1.setBounds(100, 150, 600, 50);
        prompt1.setHorizontalAlignment(SwingConstants.CENTER);

        // Second prompt - smaller font, HTML tags allowed
        JLabel prompt2 = new JLabel("<html><div style='text-align:center;'>Choose from a diverse menu featuring <i>delictable</i> array of dishes created with the finest ingredietson the wide experience</div></html>");
        prompt2.setForeground(Color.WHITE);
        prompt2.setFont(new Font("Arial", Font.PLAIN, 18));
        prompt2.setBounds(100, 210, 600, 60);
        prompt2.setHorizontalAlignment(SwingConstants.CENTER);

        // Rounded rectangle button class
        class RoundedRectangleButton extends JButton {
            private static final int ARC_WIDTH = 30;
            private static final int ARC_HEIGHT = 30;

            public RoundedRectangleButton(String label) {
                super(label);
                setOpaque(false);
                setFocusPainted(false);
                setBorderPainted(false);
                setContentAreaFilled(false);
                setForeground(Color.WHITE);
                setFont(new Font("Arial", Font.BOLD, 20));
                setBackground(new Color(106, 90, 205)); // nice green color
                setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), ARC_WIDTH, ARC_HEIGHT);
                super.paintComponent(g2);
                g2.dispose();
            }

            protected void paintBorder(Graphics g) {
                // No border
            }

            public boolean contains(int x, int y) {
                Shape roundRect = new java.awt.geom.RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), ARC_WIDTH, ARC_HEIGHT);
                return roundRect.contains(x, y);
            }
        }

        RoundedRectangleButton viewMenuButton = new RoundedRectangleButton("View Menu");
        viewMenuButton.setBounds(325, 500, 150, 60);

        // Add action listener for button (optional)
        viewMenuButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(Home.this, "View Menu button clicked!");
            }
        });

        backgroundPanel.add(prompt1);
        backgroundPanel.add(prompt2);
        backgroundPanel.add(viewMenuButton);

        setContentPane(backgroundPanel);
    }

    private class BackgroundPanel extends JPanel {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Home home = new Home();
            home.setVisible(true);
        });
    }
}
