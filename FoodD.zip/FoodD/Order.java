import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;

public class Order extends JFrame {
    // Order data class
    class OrderData {
        String userName;
        String userMobile;
        String userAddress;
        String foodItemName;
        double cost;
        int quantity;
        String status;

        public OrderData(String userName, String userMobile, String userAddress, String foodItemName, double cost, int quantity, String status) {
            this.userName = userName;
            this.userMobile = userMobile;
            this.userAddress = userAddress;
            this.foodItemName = foodItemName;
            this.cost = cost;
            this.quantity = quantity;
            this.status = status;
        }
    }

    private JPanel ordersPanel;
    private List<OrderData> orders;

    public Order(List<OrderData> orders) {
        this.orders = (orders != null) ? orders : new ArrayList<>();

        setTitle("Admin Order Panel");
        setSize(900, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        ordersPanel = new JPanel();
        ordersPanel.setLayout(new BoxLayout(ordersPanel, BoxLayout.Y_AXIS));
        ordersPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        ordersPanel.setBackground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(ordersPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        add(scrollPane, BorderLayout.CENTER);

        populateOrders();
    }

    private void populateOrders() {
        ordersPanel.removeAll();

        for (OrderData order : orders) {
            JPanel orderRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
            orderRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
            orderRow.setBackground(new Color(245, 245, 245));
            orderRow.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));

            JLabel addressLabel = new JLabel("<html>" + order.userName + "<br>" + order.userMobile + "<br>" + order.userAddress + "</html>");
            addressLabel.setPreferredSize(new Dimension(250, 60));
            addressLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            orderRow.add(addressLabel);

            JLabel foodNameLabel = new JLabel(order.foodItemName);
            foodNameLabel.setPreferredSize(new Dimension(200, 30));
            foodNameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            orderRow.add(foodNameLabel);

            JLabel costLabel = new JLabel("₹" + String.format("%.2f", order.cost));
            costLabel.setPreferredSize(new Dimension(100, 30));
            costLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            orderRow.add(costLabel);

            JLabel quantityLabel = new JLabel(String.valueOf(order.quantity));
            quantityLabel.setPreferredSize(new Dimension(50, 30));
            quantityLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            orderRow.add(quantityLabel);

            String[] statusOptions = {"Food Processing", "Out for Delivery", "Delivered"};
            JComboBox<String> statusDropdown = new JComboBox<>(statusOptions);
            statusDropdown.setSelectedItem(order.status);
            statusDropdown.setPreferredSize(new Dimension(150, 30));
            statusDropdown.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            statusDropdown.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    order.status = (String) statusDropdown.getSelectedItem();
                    // Here you can add code to update the status in database or backend if needed
                }
            });
            orderRow.add(statusDropdown);

            ordersPanel.add(orderRow);
            ordersPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        }

        ordersPanel.revalidate();
        ordersPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            List<OrderData> sampleOrders = new ArrayList<>();
            Order orderInstance = new Order(null);
            sampleOrders.add(orderInstance.new OrderData("John Doe", "9876543210", "123 Main St, City", "Margherita Pizza", 150.0, 2, "Food Processing"));
            sampleOrders.add(orderInstance.new OrderData("Jane Smith", "9123456780", "456 Elm St, City", "Chicken Burger", 160.0, 1, "Out for Delivery"));
            sampleOrders.add(orderInstance.new OrderData("Alice Johnson", "9988776655", "789 Oak St, City", "Paneer Roll", 120.0, 3, "Delivered"));

            Order adminOrderPage = new Order(sampleOrders);
            adminOrderPage.setVisible(true);
        });
    }
}
