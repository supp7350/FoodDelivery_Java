import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class Cartpage extends JFrame {
    private List<CartItem> cartItems;
    private JPanel cartPanel;
    private JLabel totalLabel;
    private double totalAmount = 0.0;
    
    public Cartpage(List<String> selectedItems) {
        cartItems = new ArrayList<>();
        
        // Parse selected items and add to cart
        for (String item : selectedItems) {
            String[] parts = item.split(" - ₹");
            if (parts.length > 1) {
                String name = parts[0];
                double price = Double.parseDouble(parts[1]);
                cartItems.add(new CartItem(name, price, 1));
            }
        }
        
        initializeComponents();
    }
    
    private void initializeComponents() {
        setTitle("Shopping Cart");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Create main panel with background
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(255, 248, 220));
        
        // Title label
        JLabel titleLabel = new JLabel("Your Shopping Cart", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titleLabel.setForeground(new Color(139, 69, 19));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        // Cart panel to display items
        cartPanel = new JPanel();
        cartPanel.setLayout(new BoxLayout(cartPanel, BoxLayout.Y_AXIS));
        cartPanel.setBackground(new Color(255, 248, 220));
        cartPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Create scroll pane for cart items
        JScrollPane scrollPane = new JScrollPane(cartPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        // Cart totals panel
        JPanel totalsPanel = new JPanel();
        totalsPanel.setLayout(new BoxLayout(totalsPanel, BoxLayout.Y_AXIS));
        totalsPanel.setBackground(new Color(255, 248, 220));
        totalsPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Subtotal label
        JLabel subtotalLabel = new JLabel("Subtotal: ₹0.00");
        subtotalLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtotalLabel.setForeground(new Color(0, 100, 0));
        subtotalLabel.setAlignmentX(Component.RIGHT_ALIGNMENT);
        subtotalLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 20));
        totalsPanel.add(subtotalLabel);
        
        // Delivery fee label
        JLabel deliveryFeeLabel = new JLabel("Delivery Fee: ₹50.00");
        deliveryFeeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        deliveryFeeLabel.setForeground(new Color(0, 100, 0));
        deliveryFeeLabel.setAlignmentX(Component.RIGHT_ALIGNMENT);
        deliveryFeeLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 20));
        totalsPanel.add(deliveryFeeLabel);
        
        // Separator
        JSeparator separator = new JSeparator(SwingConstants.HORIZONTAL);
        separator.setMaximumSize(new Dimension(Short.MAX_VALUE, 1));
        separator.setAlignmentX(Component.RIGHT_ALIGNMENT);
        separator.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 20));
        totalsPanel.add(separator);
        
        // Total label
        totalLabel = new JLabel("Total: ₹0.00");
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        totalLabel.setForeground(new Color(0, 100, 0));
        totalLabel.setAlignmentX(Component.RIGHT_ALIGNMENT);
        totalLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 20));
        totalsPanel.add(totalLabel);
        
        // Buttons panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonsPanel.setBackground(new Color(255, 248, 220));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 20));
        
        JButton checkoutButton = new JButton("Proceed to Place Order");
        styleButton(checkoutButton, new Color(34, 139, 34));
        checkoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open Address page instead of direct checkout
                Address addressPage = new Address();
                addressPage.setVisible(true);
                dispose();
            }
        });
        
        JButton continueButton = new JButton("Continue Shopping");
        styleButton(continueButton, new Color(30, 144, 255));
        continueButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        
        buttonsPanel.add(continueButton);
        buttonsPanel.add(checkoutButton);
        
        // Add components to main panel
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(totalsPanel, BorderLayout.AFTER_LAST_LINE);
        mainPanel.add(buttonsPanel, BorderLayout.PAGE_END);
        
        add(mainPanel);
        
        // Populate cart with items
        updateCartDisplay();
    }
    
    private void styleButton(JButton button, Color bgColor) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
        
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
    }
    
    private void updateCartDisplay() {
        cartPanel.removeAll();
        totalAmount = 0.0;
        
        // Add header row
        JPanel headerPanel = new JPanel(new GridBagLayout());
        headerPanel.setBackground(new Color(210, 180, 140));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        headerPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 5, 0, 5);
        
        JLabel itemHeader = new JLabel("Item");
        itemHeader.setFont(new Font("Segoe UI", Font.BOLD, 16));
        gbc.gridx = 0; gbc.weightx = 0.4;
        headerPanel.add(itemHeader, gbc);
        
        JLabel priceHeader = new JLabel("Price");
        priceHeader.setFont(new Font("Segoe UI", Font.BOLD, 16));
        gbc.gridx = 1; gbc.weightx = 0.15;
        headerPanel.add(priceHeader, gbc);
        
        JLabel qtyHeader = new JLabel("Qty");
        qtyHeader.setFont(new Font("Segoe UI", Font.BOLD, 16));
        gbc.gridx = 2; gbc.weightx = 0.15;
        headerPanel.add(qtyHeader, gbc);
        
        JLabel totalHeader = new JLabel("Total");
        totalHeader.setFont(new Font("Segoe UI", Font.BOLD, 16));
        gbc.gridx = 3; gbc.weightx = 0.15;
        headerPanel.add(totalHeader, gbc);
        
        JLabel removeHeader = new JLabel("Remove");
        removeHeader.setFont(new Font("Segoe UI", Font.BOLD, 16));
        gbc.gridx = 4; gbc.weightx = 0.15;
        headerPanel.add(removeHeader, gbc);
        
        cartPanel.add(headerPanel);
        cartPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        // Add each cart item
        for (CartItem item : cartItems) {
            JPanel itemPanel = new JPanel(new GridBagLayout());
            itemPanel.setBackground(new Color(255, 255, 255));
            itemPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
            ));
            itemPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
            
            GridBagConstraints gbc2 = new GridBagConstraints();
            gbc2.insets = new Insets(0, 5, 0, 5);
            
            // Item name
            JLabel nameLabel = new JLabel(item.getName());
            nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            gbc2.gridx = 0; gbc2.weightx = 0.4; gbc2.fill = GridBagConstraints.HORIZONTAL;
            itemPanel.add(nameLabel, gbc2);
            
            // Price
            JLabel priceLabel = new JLabel("₹" + String.format("%.2f", item.getPrice()));
            priceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            gbc2.gridx = 1; gbc2.weightx = 0.15; gbc2.fill = GridBagConstraints.NONE;
            itemPanel.add(priceLabel, gbc2);
            
            // Quantity spinner
            SpinnerNumberModel spinnerModel = new SpinnerNumberModel(item.getQuantity(), 1, 100, 1);
            JSpinner qtySpinner = new JSpinner(spinnerModel);
            qtySpinner.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            qtySpinner.addChangeListener(e -> {
                int newQty = (Integer) qtySpinner.getValue();
                item.setQuantity(newQty);
                updateItemTotal(item, totalLabel);
            });
            gbc2.gridx = 2; gbc2.weightx = 0.15;
            itemPanel.add(qtySpinner, gbc2);
            
            // Item total
            JLabel itemTotalLabel = new JLabel("₹" + String.format("%.2f", item.getTotalPrice()));
            itemTotalLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            itemTotalLabel.setName("total_" + item.getName());
            gbc2.gridx = 3; gbc2.weightx = 0.15;
            itemPanel.add(itemTotalLabel, gbc2);
            
            // Remove button
            JButton removeButton = new JButton("Remove");
            removeButton.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            removeButton.setBackground(new Color(220, 20, 60));
            removeButton.setForeground(Color.WHITE);
            removeButton.setFocusPainted(false);
            removeButton.addActionListener(e -> {
                cartItems.remove(item);
                updateCartDisplay();
            });
            gbc2.gridx = 4; gbc2.weightx = 0.15;
            itemPanel.add(removeButton, gbc2);
            
            cartPanel.add(itemPanel);
            cartPanel.add(Box.createRigidArea(new Dimension(0, 5)));
            
            totalAmount += item.getTotalPrice();
        }
        
        totalLabel.setText("Total: ₹" + String.format("%.2f", totalAmount));
        cartPanel.revalidate();
        cartPanel.repaint();
    }
    
    private void updateItemTotal(CartItem item, JLabel totalLabel) {
        totalAmount = 0.0;
        for (CartItem cartItem : cartItems) {
            totalAmount += cartItem.getTotalPrice();
        }
        totalLabel.setText("Total: ₹" + String.format("%.2f", totalAmount));
    }
    
    private void checkout() {
        if (cartItems.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your cart is empty!", "Checkout", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        JOptionPane.showMessageDialog(this, 
            "Order placed successfully!\nTotal amount: ₹" + String.format("%.2f", totalAmount),
            "Checkout", 
            JOptionPane.INFORMATION_MESSAGE);
        
        // Clear cart and close window
        cartItems.clear();
        dispose();
    }
    
    // Inner class to represent a cart item
    class CartItem {
        private String name;
        private double price;
        private int quantity;
        
        public CartItem(String name, double price, int quantity) {
            this.name = name;
            this.price = price;
            this.quantity = quantity;
        }
        
        public String getName() {
            return name;
        }
        
        public double getPrice() {
            return price;
        }
        
        public int getQuantity() {
            return quantity;
        }
        
        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
        
        public double getTotalPrice() {
            return price * quantity;
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
                // Create a sample cart with some items for testing
                List<String> sampleItems = new ArrayList<>();
                sampleItems.add("Margherita Pizza - ₹150.0");
                sampleItems.add("Chicken Burger - ₹160.0");
                sampleItems.add("Paneer Roll - ₹120.0");
                
                new Cartpage(sampleItems).setVisible(true);
            }
        });
    }
}
