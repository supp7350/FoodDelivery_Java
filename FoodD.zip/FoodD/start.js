// Interactive Start Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Particle system
    const particleContainer = document.getElementById('particleContainer');
    const particleCount = 50;

    for (let i = 0; i < particleCount; i++) {
        createParticle();
    }

    function createParticle() {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 10 + 's';
        particle.style.animationDuration = (Math.random() * 10 + 5) + 's';
        particleContainer.appendChild(particle);
    }

    // Logo interaction
    const logo = document.querySelector('.logo');
    logo.addEventListener('click', function(e) {
        createRipple(e, this);
        animateLogo();
    });

    function animateLogo() {
        logo.style.animation = 'none';
        setTimeout(() => {
            logo.style.animation = 'pulse 0.5s ease-in-out 3';
        }, 10);
    }

    // Button interactions
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            createRipple(e, this);
            handleButtonClick(this);
        });
    });

    function handleButtonClick(button) {
        const action = button.dataset.action;
        
        switch(action) {
            case 'start':
                startApplication();
                break;
            case 'explore':
                exploreFeatures();
                break;
            case 'login':
                navigateToLogin();
                break;
        }
    }

    // Ripple effect
    function createRipple(event, element) {
        const ripple = document.createElement('span');
        ripple.className = 'ripple';
        
        const rect = element.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;
        
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        
        element.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    }

    // Hover zones interaction
    const hoverZones = document.querySelectorAll('.hover-zone');
    hoverZones.forEach(zone => {
        zone.addEventListener('mouseenter', function() {
            const color = this.dataset.color;
            document.body.style.background = `linear-gradient(135deg, ${color}, #ffa500)`;
            document.body.style.backgroundSize = '400% 400%';
        });

        zone.addEventListener('mouseleave', function() {
            document.body.style.background = 'linear-gradient(135deg, #ff6b6b, #ffa500, #ff6b6b)';
            document.body.style.backgroundSize = '400% 400%';
        });
    });

    // Mouse tracking effect
    document.addEventListener('mousemove', function(e) {
        const cursor = document.querySelector('.cursor');
        if (!cursor) {
            const newCursor = document.createElement('div');
            newCursor.className = 'cursor';
            newCursor.style.cssText = `
                position: fixed;
                width: 20px;
                height: 20px;
                background: rgba(255, 255, 255, 0.5);
                border-radius: 50%;
                pointer-events: none;
                z-index: 9999;
                transition: transform 0.1s ease;
            `;
            document.body.appendChild(newCursor);
        }
        
        const cursor = document.querySelector('.cursor');
        cursor.style.left = e.clientX - 10 + 'px';
        cursor.style.top = e.clientY - 10 + 'px';
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            startApplication();
        }
        if (e.key === 'Escape') {
            showMenu();
        }
    });

    // Application functions
    function startApplication() {
        // Add loading animation
        const loadingBar = document.querySelector('.loading-bar');
        loadingBar.style.opacity = '1';
        
        setTimeout(() => {
            window.location.href = 'Home.java'; // Navigate to home page
        }, 3000);
    }

    function exploreFeatures() {
        // Show feature modal
        showFeatureModal();
    }

    function navigateToLogin() {
        window.location.href = 'Login.java';
    }

    function showFeatureModal() {
        const modal = document.createElement('div');
        modal.className = 'feature-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <h2>Welcome to Yumm..</h2>
                <p>Discover amazing food experiences:</p>
                <ul>
                    <li>🍕 Browse delicious menus</li>
                    <li>🛒 Easy cart management</li>
                    <li>📱 Track your orders</li>
                    <li>⭐ Rate and review</li>
                </ul>
                <button class="btn" onclick="this.parentElement.parentElement.remove()">Got it!</button>
            </div>
        `;
        
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        `;
        
        modal.querySelector('.modal-content').style.cssText = `
            background: white;
            color: #333;
            padding: 2rem;
            border-radius: 20px;
            max-width: 400px;
            text-align: center;
        `;
        
        document.body.appendChild(modal);
    }

    // Touch support for mobile
    let touchStartY = 0;
    let touchEndY = 0;

    document.addEventListener('touchstart', function(e) {
        touchStartY = e.changedTouches[0].screenY;
    });

    document.addEventListener('touchend', function(e) {
        touchEndY = e.changedTouches[0].screenY;
        handleSwipe();
    });

    function handleSwipe() {
        if (touchEndY < touchStartY - 50) {
            // Swipe up
            startApplication();
        }
    }

    // Easter egg
    let clickCount = 0;
    logo.addEventListener('click', function() {
        clickCount++;
        if (clickCount === 5) {
            showEasterEgg();
            clickCount = 0;
        }
    });

    function showEasterEgg() {
        const egg = document.createElement('div');
        egg.innerHTML = '🎉 Welcome to Yumm..! 🎉';
        egg.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 2rem;
            color: white;
            background: linear-gradient(45deg, #ff6b6b, #ffa500);
            padding: 2rem;
            border-radius: 20px;
            z-index: 1001;
            animation: bounce 1s ease;
        `;
        
        document.body.appendChild(egg);
        
        setTimeout(() => {
            egg.remove();
        }, 2000);
    }

    // Auto-start after 5 seconds
    setTimeout(() => {
        if (!document.querySelector('.feature-modal')) {
            startApplication();
        }
    }, 5000);

    // Add CSS for animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translate(-50%, -50%) translateY(0);
            }
            40% {
                transform: translate(-50%, -50%) translateY(-30px);
            }
            60% {
                transform: translate(-50%, -50%) translateY(-15px);
            }
        }
    `;
    document.head.appendChild(style);
});
